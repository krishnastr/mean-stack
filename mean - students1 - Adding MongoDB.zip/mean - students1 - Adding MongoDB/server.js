const http = require("http");
// Added - Impor EXPRESS
const express = require("express");
const mongoose = require("mongoose");
const Student = require("./models/students");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
mongoose.connect("mongodb+srv://jpbala:bala1234@meancluster1-xj3tu.mongodb.net/test?retryWrites=true&w=majority", { useNewUrlParser: true, useUnifiedTopology: true })
.then(() => {
  console.log("Connected to database!");
})
.catch(() => {
  console.log("Connection faile");
});

app.get('/api', (reqs, resp) => {
  Student.find().then(students => {
    resp.status(200).json(students);
  })
});

app.post('/api', (reqs, resp) => {
  console.log(reqs.body);
  student = new Student({
    name: reqs.body.name,
    class: reqs.body.class
  })
  student.save().then(createdStudent => {
    resp.status(200).json({student: createdStudent});
  })
})



app.listen(4444, () => console.log('Server is listening on PORT 4444'));